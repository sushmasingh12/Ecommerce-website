/**
 * validate(schema)
 * Express middleware factory — Joi schema se request body validate karta hai.
 * Validation fail hone par 422 ke saath readable error messages return karta hai.
 */
const validate = (schema) => (req, res, next) => {
    const { error, value } = schema.validate(req.body, {
        abortEarly: false,   // saare errors ek saath dikhao, pehle wale par rukna nahi
        stripUnknown: true,  // allowed fields ke alawa sab kuch hata do
    });

    if (error) {
        const messages = error.details.map((d) => d.message);
        return res.status(422).json({
            success: false,
            message: 'Validation failed.',
            errors: messages,
        });
    }

    // Validated + sanitized value ko body par replace karo
    req.body = value;
    next();
};

export default validate;
