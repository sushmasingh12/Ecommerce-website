import * as authService from './auth_service.js';

// ─── Cookie Config ────────────────────────────────────────────────────────────
const COOKIE_OPTIONS = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
    maxAge: 30 * 24 * 60 * 60 * 1000,
};

const setTokenCookie = (res, token) => {
    res.cookie('adminToken', token, COOKIE_OPTIONS);
};

const clearTokenCookie = (res) => {
    res.clearCookie('adminToken', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
    });
};

// ─── Controllers ──────────────────────────────────────────────────────────────

export const signup = async (req, res) => {
    try {
        await authService.registerAdmin(req.body);
        res.status(201).json({
            success: true,
            message: 'OTP sent to your email. Please verify to complete registration.',
        });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

export const verify = async (req, res) => {
    try {
        const { email, otp } = req.body;
        const admin = await authService.verifyOTP(email, otp);
        const token = authService.generateToken(admin._id);

        setTokenCookie(res, token);

        res.status(200).json({
            success: true,
            message: 'Email verified successfully.',
            admin: {
                id: admin._id,
                name: admin.name,
                email: admin.email,
                phone: admin.phone,
            },
        });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

export const signin = async (req, res) => {
    try {
        const { email, password } = req.body;
        const admin = await authService.loginAdmin(email, password);
        const token = authService.generateToken(admin._id);

        setTokenCookie(res, token);

        res.status(200).json({
            success: true,
            admin: {
                id: admin._id,
                name: admin.name,
                email: admin.email,
                phone: admin.phone,
            },
        });
    } catch (error) {
        res.status(401).json({ success: false, message: error.message });
    }
};

export const resendOtp = async (req, res) => {
    try {
        const { email } = req.body;
        await authService.resendOTP(email);
        res.status(200).json({
            success: true,
            message: 'OTP resent successfully. Please check your email.',
        });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

export const signout = (_req, res) => {
    clearTokenCookie(res);
    res.status(200).json({ success: true, message: 'Signed out successfully.' });
};
