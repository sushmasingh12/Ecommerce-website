
import Joi from 'joi';

// ─── Signup ───────────────────────────────────────────────────────────────────
export const signupSchema = Joi.object({
    name: Joi.string().min(2).max(60).trim().required().messages({
        'string.empty': 'Name is required.',
        'string.min': 'Name must be at least 2 characters.',
        'string.max': 'Name must not exceed 60 characters.',
        'any.required': 'Name is required.',
    }),

    email: Joi.string()
        .email({ tlds: { allow: false } })
        .lowercase()
        .trim()
        .required()
        .messages({
            'string.empty': 'Email is required.',
            'string.email': 'Please provide a valid email address.',
            'any.required': 'Email is required.',
        }),

    phone: Joi.string()
        .pattern(/^[6-9]\d{9}$/)
        .required()
        .messages({
            'string.empty': 'Phone number is required.',
            'string.pattern.base': 'Please provide a valid 10-digit Indian phone number.',
            'any.required': 'Phone number is required.',
        }),

    password: Joi.string().min(8).max(128).required().messages({
        'string.empty': 'Password is required.',
        'string.min': 'Password must be at least 8 characters.',
        'string.max': 'Password must not exceed 128 characters.',
        'any.required': 'Password is required.',
    }),
});

// ─── Verify OTP ───────────────────────────────────────────────────────────────
export const verifySchema = Joi.object({
    email: Joi.string()
        .email({ tlds: { allow: false } })
        .lowercase()
        .trim()
        .required()
        .messages({
            'string.empty': 'Email is required.',
            'string.email': 'Please provide a valid email address.',
            'any.required': 'Email is required.',
        }),

    otp: Joi.string()
        .pattern(/^\d{6}$/)
        .required()
        .messages({
            'string.empty': 'OTP is required.',
            'string.pattern.base': 'OTP must be exactly 6 digits.',
            'any.required': 'OTP is required.',
        }),
});

// ─── Signin ───────────────────────────────────────────────────────────────────
export const signinSchema = Joi.object({
    email: Joi.string()
        .email({ tlds: { allow: false } })
        .lowercase()
        .trim()
        .required()
        .messages({
            'string.empty': 'Email is required.',
            'string.email': 'Please provide a valid email address.',
            'any.required': 'Email is required.',
        }),

    password: Joi.string().min(8).required().messages({
        'string.empty': 'Password is required.',
        'string.min': 'Password must be at least 8 characters.',
        'any.required': 'Password is required.',
    }),
});

// ─── Resend OTP ───────────────────────────────────────────────────────────────
export const resendOtpSchema = Joi.object({
    email: Joi.string()
        .email({ tlds: { allow: false } })
        .lowercase()
        .trim()
        .required()
        .messages({
            'string.empty': 'Email is required.',
            'string.email': 'Please provide a valid email address.',
            'any.required': 'Email is required.',
        }),
});
