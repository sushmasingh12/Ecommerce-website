import express from 'express';
import { signup, verify, signin, resendOtp, signout } from './auth_controller.js';
import validate from './auth_middleware.js';
import {
    signupSchema,
    verifySchema,
    signinSchema,
    resendOtpSchema,
} from './auth_validation.js';

const router = express.Router();

router.post('/signup', validate(signupSchema), signup);
router.post('/verify', validate(verifySchema), verify);
router.post('/signin', validate(signinSchema), signin);
router.post('/resend-otp', validate(resendOtpSchema), resendOtp);
router.post('/signout', signout);

export default router;
