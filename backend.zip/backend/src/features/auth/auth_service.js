import Admin from './admin_model.js';
import generateOTP from '../../utils/generateOTP.js';
import sendEmail from '../../utils/sendEmail.js';
import jwt from 'jsonwebtoken';

// ─── Register ─────────────────────────────────────────────────────────────────
export const registerAdmin = async ({ name, email, phone, password }) => {
    const existing = await Admin.findOne({ $or: [{ email }, { phone }] });
    if (existing) {
        if (existing.email === email) throw new Error('Admin with this email already exists.');
        throw new Error('Admin with this phone number already exists.');
    }

    const otp = generateOTP();
    const otpExpire = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    const admin = await Admin.create({ name, email, phone, password, otp, otpExpire });

    await sendEmail({
        email: admin.email,
        subject: 'Admin Account Verification OTP',
        message: `Your verification code is ${otp}. It will expire in 10 minutes.`,
    });

    return admin;
};

// ─── Verify OTP ───────────────────────────────────────────────────────────────
export const verifyOTP = async (email, otp) => {
    const admin = await Admin.findOne({ email, otp, otpExpire: { $gt: Date.now() } });

    if (!admin) throw new Error('Invalid or expired OTP.');

    admin.isVerified = true;
    admin.otp = undefined;
    admin.otpExpire = undefined;
    await admin.save();

    return admin;
};

// ─── Resend OTP ───────────────────────────────────────────────────────────────
export const resendOTP = async (email) => {
    const admin = await Admin.findOne({ email });

    if (!admin) throw new Error('No account found with this email.');
    if (admin.isVerified) throw new Error('This account is already verified.');

    const otp = generateOTP();
    const otpExpire = new Date(Date.now() + 10 * 60 * 1000);

    admin.otp = otp;
    admin.otpExpire = otpExpire;
    await admin.save();

    await sendEmail({
        email: admin.email,
        subject: 'Admin Account Verification OTP (Resend)',
        message: `Your new verification code is ${otp}. It will expire in 10 minutes.`,
    });
};

// ─── Login ────────────────────────────────────────────────────────────────────
export const loginAdmin = async (email, password) => {
    const admin = await Admin.findOne({ email }).select('+password');

    if (!admin) throw new Error('Invalid credentials.');
    if (!admin.isVerified) throw new Error('Please verify your account first.');

    const isMatch = await admin.matchPassword(password);
    if (!isMatch) throw new Error('Invalid credentials.');

    return admin;
};

// ─── JWT ──────────────────────────────────────────────────────────────────────
export const generateToken = (id) =>
    jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
